# Allez au drive du cours
==> 03 - partie 3 - VAEs et génération de nouvelles images
