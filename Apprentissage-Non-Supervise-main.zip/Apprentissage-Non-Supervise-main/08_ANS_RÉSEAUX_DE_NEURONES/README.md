# LIENS: 

- https://github.com/vdumoulin/conv_arithmetic/blob/master/README.md
- https://github.com/hrhouma/conv_arithmetic/blob/master/README.md
- https://yosinski.com/deepvis
- https://keras.io/api/applications/
- https://deeplizard.com/learn/video/qSTv_m-KFk0
- https://setosa.io/ev/image-kernels/


