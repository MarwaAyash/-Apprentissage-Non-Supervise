# towardsdatascience
- https://towardsdatascience.com/convolutional-neural-networks-explained-9cc5188c4939
- https://towardsai.net/p/machine-learning/understanding-convolutional-neural-network-cnn-a-guide-to-visual-recognition-in-the-ai-era

# medium
- https://medium.com/codex/understanding-convolutional-neural-networks-a-beginners-journey-into-the-architecture-aab30dface10
- https://medium.com/@speaktoharisudhan/understanding-cnn-convolutional-neural-network-3b75bb195555

# youtube
- https://www.youtube.com/watch?v=YRhxdVk_sIs&ab_channel=deeplizard
- https://www.youtube.com/watch?v=aircAruvnKk&ab_channel=3Blue1Brown
- https://www.youtube.com/watch?v=QzY57FaENXg&ab_channel=IBMTechnology

# ieeexplore
- https://ieeexplore.ieee.org/document/8308186


