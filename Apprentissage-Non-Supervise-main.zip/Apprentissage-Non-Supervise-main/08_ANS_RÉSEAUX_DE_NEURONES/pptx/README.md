# Important: 
- Les diapositives peuvent être téléchargés à partir du DRIVE du cours.
- Veuillez trouver ci-bas les titres des diapositives.
  
# Titres
1. **Introduction à l'Intelligence Artificielle et à l'Apprentissage Machine : Théorie**
2. **Pratique de l'IA et de l'Apprentissage Profond avec Google Colab et TensorFlow**
3. **Atelier Pratique : Construction et Entraînement de Modèles Supervisés et Non Supervisés avec TensorFlow**
4. **Théorie Avancée de l'Apprentissage Profond : Réseaux de Neurones Supervisés et Non Supervisés**
5. **Réseaux de Neurones Convolutifs : Concepts, Applications et Apprentissage Non Supervisé**
6. **Révision des Concepts de Régression, Classification et Apprentissage Non Supervisé en Apprentissage Profond**
7. **Apprentissage par Gradient pour la Reconnaissance de Documents : Approches Supervisées et Non Supervisées**
8. **Optimisation pour l'Apprentissage Profond : Méthodes et Techniques Supervisées et Non Supervisées**
