# Convolution arithmetic
- https://github.com/vdumoulin/conv_arithmetic/blob/master/README.md
