## Références : 
- https://www.javatpoint.com/hierarchical-clustering-in-machine-learning
- https://www.geeksforgeeks.org/hierarchical-clustering/
- https://www.youtube.com/watch?v=XJ3194AmH40&ab_channel=VictorLavrenko
  
