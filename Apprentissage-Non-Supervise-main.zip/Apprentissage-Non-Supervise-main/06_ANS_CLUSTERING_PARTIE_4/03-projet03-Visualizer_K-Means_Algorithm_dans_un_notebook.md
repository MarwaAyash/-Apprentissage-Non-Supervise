

- https://code-specialist.com/python/k-means-algorithm
