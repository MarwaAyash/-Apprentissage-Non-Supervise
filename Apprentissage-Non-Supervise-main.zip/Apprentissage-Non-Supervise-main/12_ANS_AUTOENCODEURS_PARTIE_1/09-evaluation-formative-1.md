
1. **Qu'est-ce qu'un autoencodeur et à quoi sert-il ?**

2. **Quelle est la différence entre l'encodeur et le décodeur dans un autoencodeur ?**

3. **Comment un autoencodeur peut-il être utilisé pour réduire le bruit dans une image ?**

4. **Quel est le rôle de la couche cachée dans un autoencodeur ?**

5. **Pourquoi est-il important de normaliser les données avant de les utiliser dans un autoencodeur ?**

6. **Dans le modèle `Sequential`, pourquoi doit-on ajouter des couches d'activation comme ReLU ?**

7. **Qu'est-ce qu'une perte (`loss`) dans le contexte d'un autoencodeur, et pourquoi est-elle importante ?**

8. **Comment savoir si un autoencodeur fonctionne bien pour la tâche de reconstruction d'images ?**

9. **Quelle est la différence entre un autoencodeur sous-complet et un autoencodeur surcomplet ?**

10. **Pourquoi pourrait-on utiliser un autoencodeur comme étape de prétraitement avant un autre modèle d'apprentissage automatique ?**
