# Liens utiles : 

## Vidéo 1
- https://www.youtube.com/watch?v=FTtzd31IAOw&t=1065s&ab_channel=MachineLearnia
- https://github.com/MachineLearnia
- https://github.com/MachineLearnia/Python-Machine-Learning
- https://github.com/hrhouma/Apprentissage-Non-Supervise-1/blob/main/video1.md

## Vidéo 2

- https://www.youtube.com/watch?v=HuK48FxITao&t=14s&ab_channel=InformatiqueSansComplexe
- https://github.com/hrhouma/Apprentissage-Non-Supervise-1/blob/main/video2.md

## MON MATÉRIEL
- MON LIEN DRIVE (ME CONTACTER)
