
### Section 1 : Le Regroupement (Clustering)
63. Introduction de la section
64. Bases du clustering
65. Clustering K-means
66. DÉMO : Clustering K-means en Python
67. Visualisation des clusters K-means
68. Interprétation des clusters K-means
69. DÉMO : Visualisation des centres de clusters
70. Devoir : Clustering K-means
71. SOLUTION : Clustering K-means
72. Inertie
73. DÉMO : Inertie en Python
74. Devoir : Tracer l'inertie
75. SOLUTION : Tracer l'inertie
76. Ajustement d'un modèle K-means
77. DÉMO : Ajustement d'un modèle K-means
78. Devoir : Ajustement d'un modèle K-means
79. SOLUTION : Ajustement d'un modèle K-means
80. Sélection du meilleur modèle
81. DÉMO : Sélection du meilleur modèle
82. Devoir : Sélection du meilleur modèle
83. SOLUTION : Sélection du meilleur modèle
84. Clustering hiérarchique
85. Dendrogrammes en Python
86. Clustering agglomératif en Python
87. DÉMO : Clustering agglomératif en Python
88. Cartes de clusters en Python
89. DÉMO : Cartes de clusters en Python
90. Devoir : Clustering hiérarchique
91. SOLUTION : Clustering hiérarchique
92. DBSCAN
93. DBSCAN en Python
94. Score de silhouette
95. DÉMO : Score de silhouette en Python
96. Devoir : DBSCAN
97. SOLUTION : DBSCAN
98. Comparaison des algorithmes de clustering
99. Étapes suivantes du clustering
100. DÉMO : Comparer les modèles de clustering
101. DÉMO : Étiqueter des données non vues
102. Points clés
103. Quiz 4 : Clustering
