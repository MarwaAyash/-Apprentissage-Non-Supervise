# Plan de la séance

# 1. Théorie - Imagerie
- **Document GitHub** : 08-ANN-intro-reseaux-neurones-apprentissage-non-supervise/01-cours-intro-imagerie.md

# 2. Exercices - Imagerie
- **Lien Drive** : code-partie-4-les-bases-de-limagerie

# 3. Théorie - Réseaux de Neurones
- **Dossier Théorie** : Doosier Théorie
- **Document GitHub** : Apprentissage-Non-Supervise/08-ANN-intro-reseaux-neurones-apprentissage-non-supervise/03-cours-intro-reseaux-de-neurones

# 4. Exercices - Réseaux de Neurones
- **Lien Drive** : 10-Réseaux-de-neurones/02-pratique/code-partie-1-introduction-a-tensorflow-et-RNN

# 5. Exercices et Quiz
- dossier : 07-evaluation-formative.md
