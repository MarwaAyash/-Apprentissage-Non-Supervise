# PARTIE 1 : 

1 - https://www.kaggle.com/code/praxitelisk/anomaly-detection-techniques-summary#Anomaly-Detection-Techniques-Summary

# PARTIE 2 :

1 - https://medium.com/@limyenwee_19946/unsupervised-outlier-detection-with-isolation-forest-eab398c593b2

2 - https://github.com/youngdataspace/Detect-Outliers-Using-Isolation-Forest/tree/main

3 - https://www.analyticsvidhya.com/blog/2021/07/anomaly-detection-using-isolation-forest-a-complete-guide/




# RESSOURCES COMPLÈTES (AVANCÉ) : 
- https://github.com/yzhao062/anomaly-detection-resources
- https://github.com/openvinotoolkit/anomalib
- https://github.com/M-3LAB/awesome-industrial-anomaly-detection


# Autres références partie 1 : 

- https://www.google.com/search?q=kaggle+anomaly+detection&sca_esv=b5b06c2b2ff8ca96&sxsrf=ADLYWIKqLmP-EahELZY7eOk_gLDkJcFr_w:1723302304935&ei=oIG3ZtjLOJ605NoPyImEuQs&start=10&sa=N&sstk=AagrsuiA9G-kVF2fxaZpXS-zpSUNWii2gAdda7AtyjGn9fFf2Jn7hINOUQ3S84Qp5kdhUxBPwtqDABsFJt2NETXdTcooPsmNsMgiqA&ved=2ahUKEwjYm-et2eqHAxUeGlkFHcgEIbcQ8tMDegQIAxAE&biw=1707&bih=820&dpr=1.13
- https://www.kaggle.com/code/victorambonati/unsupervised-anomaly-detection
- https://www.kaggle.com/code/drscarlat/compare-6-unsupervised-anomaly-detection-models
- https://www.kaggle.com/code/naveengowda16/anomaly-detection-credit-card-fraud-analysis
- https://www.kaggle.com/discussions/questions-and-answers/449013
- https://www.kaggle.com/code/leomauro/anomaly-detection-streaming-data
- https://www.kaggle.com/code/robinteuwens/anomaly-detection-with-auto-encoders
- https://www.kaggle.com/discussions/general/128356
- https://www.kaggle.com/code/praxitelisk/anomaly-detection-techniques-summary#Anomaly-Detection-Techniques-Summary



# Autres références partie 2 : 

- https://www.sqlshack.com/time-series-anomaly-detection-in-azure-machine-learning/
- https://www.sqlshack.com/time-series-anomaly-detection-in-azure-machine-learning/
- https://learn.microsoft.com/en-us/azure/architecture/example-scenario/ai/real-time-anomaly-detection-conveyor-belt
- https://fintelics.medium.com/an-introduction-to-microsoft-azure-anomaly-detection-service-fc80a4da87d9
- https://caiomsouza.medium.com/machine-learning-algorithm-cheat-sheet-for-azure-machine-learning-designer-d355939e6892
- https://medium.com/@getprithivee/features-and-capabilities-of-azure-machine-learning-868eb3b4d333
- https://medium.com/ad-tech/aws-vs-azure-anomaly-detection-902375452f44
- https://easonlai888.medium.com/azure-anomaly-detector-api-to-analyze-stock-performance-data-4672b1ee492c
- https://towardsdatascience.com/time-series-anomaly-detection-with-pycaret-706a6e2b2427

