- https://github.com/youngdataspace/Detect-Outliers-Using-Isolation-Forest/tree/main
- https://github.com/hrhouma/Detect-Outliers-Using-Isolation-Forest/tree/main (FORK)

