# Apprentissage-Non-Supervise


---
# Partie détection des anomalies
----

==> DRIVE DU COURS : 

 - dossiers 13 et 14 (partie 1 et partie 2)

- https://drive.google.com/drive/folders/1kGx1bGp_TmMUm5hdzj0t0ILYvUY6MVln
- https://drive.google.com/drive/folders/1H7kbeWT_kd-vCTm3jFhZygDMAl28kdJn

==> GITHUB:

- LES DOSSIERS commençant par le chiffre 09

- https://github.com/hrhouma/Apprentissage-Non-Supervise/tree/main/09_ANS_D%C3%89TECTION_DES_ANOMALIES
- https://github.com/hrhouma/Apprentissage-Non-Supervise/tree/main/09_ANS_D%C3%89TECTION_DES_ANOMALIES-p2
- https://github.com/hrhouma/Apprentissage-Non-Supervise/tree/main/09_ANS_D%C3%89TECTION_DES_ANOMALIES-p3
