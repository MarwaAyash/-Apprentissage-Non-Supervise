# Liens des QUIZ :

## QUIZ 1 GÉNÉRAL (60 QUESTIONS): 
- https://forms.office.com/r/2TJ3VA13jD

## QUIZ 2 AVEC DU CODE (10 QUESTIONS):
- https://forms.office.com/r/2TJ3VA13jD

## QUIZ 3 OPTIMISATION (TO DO):
- À VENIR
