# IMPORTANT (LIEN DES PRATIQUES)
- https://drive.google.com/drive/folders/1vbrcgJiY2dHB8U3HlNixxxwxCg6apA2C?usp=sharing
-----------
✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️
# 02-pratique01-DBSCAN-eps-min_samples-partie02.md
✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️
# python .\test-nader-1.py
![image](https://github.com/hrhouma/Apprentissage-Non-Supervise/assets/10111526/b755860a-0906-419f-a283-255510502c01)
# python .\test-nader-9.py
![image](https://github.com/hrhouma/Apprentissage-Non-Supervise/assets/10111526/db8b24f2-cbf1-4502-9799-622531135536)

-----------
✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️
# 03-pratique01-DBSCAN-eps-min_samples-partie03.md
✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️
![image](https://github.com/hrhouma/Apprentissage-Non-Supervise/assets/10111526/e9c9aa3a-6013-44fb-b71c-94426b39ccae)

---------------
✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️
# 05-pratique03-Visualisation-et-Optimisation-de-DBSCAN.md
✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️✈️
![image](https://github.com/hrhouma/Apprentissage-Non-Supervise/assets/10111526/2211144a-1373-42b1-ac8a-68c1dae683b5)





