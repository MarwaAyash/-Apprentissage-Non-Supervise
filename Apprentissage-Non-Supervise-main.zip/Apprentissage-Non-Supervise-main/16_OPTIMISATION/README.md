# TO DO 
# Projets

- Projet 1 : Projet de Segmentation des Clients Bancaires 
- Projet 2 : Projet Taxi Clustering des données de géolocalisation intelligemment en Python
- Projet 3 :
- Projet 4:


